# ImageHoster by UpGrad

This is Image hoster project

>This project has following features:

1. User can login
2. User can upload images.
3. User can add tags for uploaded Images.
4. User can view all the uploaded images and comments for any images.
5. If a logged in User tries to edit or delete files uploaded by other Users, the action is not allowed and an error message is displayed.
6. Validates password for profile creation.
7. Passwords with 1 alphabet, 1 digit and 1 special character are only allowed else an error message is displayed.
